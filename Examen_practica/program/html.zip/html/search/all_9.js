var searchData=
[
  ['n_55',['N',['../class_area___emmagatzematge.html#ad5545192b2cde34c027a20e9e9690371',1,'Area_Emmagatzematge']]]
];
