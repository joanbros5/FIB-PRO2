var searchData=
[
  ['quitahueco_170',['QuitaHueco',['../class_area___emmagatzematge.html#afac93abffa6512ed3d64fa64df41da4c',1,'Area_Emmagatzematge']]]
];
