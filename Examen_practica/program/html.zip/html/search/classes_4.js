var searchData=
[
  ['segmento_104',['Segmento',['../class_segmento.html',1,'']]]
];
