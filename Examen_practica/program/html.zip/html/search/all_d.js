var searchData=
[
  ['recolocar_5fespera_71',['recolocar_espera',['../class_area___emmagatzematge.html#a9e8250dd30f9a31abe120f0ade73168e',1,'Area_Emmagatzematge']]],
  ['retira_72',['retira',['../class_area___emmagatzematge.html#acd9a67e4ad610fb67bba89c4f32ef123',1,'Area_Emmagatzematge']]],
  ['retiraencima_73',['retiraEncima',['../class_area___emmagatzematge.html#a3bb8520e239da5f09d8828ca04b85c6a',1,'Area_Emmagatzematge']]]
];
