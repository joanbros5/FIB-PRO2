var searchData=
[
  ['area_189',['Area',['../class_area___emmagatzematge.html#a0cabcb6de789d01a92caf090175cf93f',1,'Area_Emmagatzematge']]]
];
