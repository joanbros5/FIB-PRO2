var searchData=
[
  ['dividehuecos_26',['DivideHuecos',['../class_cjt___huecos.html#a870581a4105f3fc6cb28737b496f6008',1,'Cjt_Huecos']]],
  ['dondecont_27',['DondeCont',['../class_area___emmagatzematge.html#a6ea81fbe69d4a043ea2f695d7bcc3639',1,'Area_Emmagatzematge']]]
];
