var searchData=
[
  ['pràctica_20sobre_20la_20terminal_20de_20contenidors_20i_20la_20estratègia_20best_5ffit_209',['Pràctica sobre la terminal de contenidors i la estratègia BEST_FIT',['../index.html',1,'']]]
];
