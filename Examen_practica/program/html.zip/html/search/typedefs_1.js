var searchData=
[
  ['piso_207',['Piso',['../_area___emmagatzematge_8cc.html#a07b661e3bf5c0eec5886bbbbeb4e1bc3',1,'Area_Emmagatzematge.cc']]],
  ['plaza_208',['Plaza',['../_area___emmagatzematge_8cc.html#a52db53a5b4282dd60b05b7fc7f259098',1,'Area_Emmagatzematge.cc']]]
];
