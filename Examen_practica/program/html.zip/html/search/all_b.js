var searchData=
[
  ['pràctica_20sobre_20la_20terminal_20de_20contenidors_20i_20la_20estratègia_20best_5ffit_63',['Pràctica sobre la terminal de contenidors i la estratègia BEST_FIT',['../index.html',1,'']]],
  ['piso_64',['piso',['../class_ubicacion.html#af6099f8de4dee993e4c9119e1f879070',1,'Ubicacion::piso()'],['../_area___emmagatzematge_8cc.html#a07b661e3bf5c0eec5886bbbbeb4e1bc3',1,'Piso():&#160;Area_Emmagatzematge.cc']]],
  ['pisos_65',['pisos',['../class_area___emmagatzematge.html#a6c91a6164f5009e93bc073ecbfeb6c04',1,'Area_Emmagatzematge']]],
  ['plaza_66',['plaza',['../class_ubicacion.html#abed323ffb2eace375e80bc395fdaeb39',1,'Ubicacion::plaza()'],['../_area___emmagatzematge_8cc.html#a52db53a5b4282dd60b05b7fc7f259098',1,'Plaza():&#160;Area_Emmagatzematge.cc']]],
  ['plazas_67',['plazas',['../class_area___emmagatzematge.html#afb748963a77571a46739f84185bccbd3',1,'Area_Emmagatzematge']]],
  ['print_68',['print',['../class_contenedor.html#abcffc39995e62a9ddad113b2cfeb3279',1,'Contenedor::print()'],['../class_hueco.html#a558c929d0638abdc79dcd2fd6c86f11c',1,'Hueco::print()'],['../class_segmento.html#ac6f9e53987e915d2d0b6847aeb8e49ed',1,'Segmento::print()'],['../class_ubicacion.html#a6b693a32d8bbd9afce30b11d19b68846',1,'Ubicacion::print()']]],
  ['program_2ecc_69',['program.cc',['../program_8cc.html',1,'']]]
];
