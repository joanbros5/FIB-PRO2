var searchData=
[
  ['h_40',['H',['../class_area___emmagatzematge.html#a0dcff0ca0060b1bcb6fcd7423e8c4b72',1,'Area_Emmagatzematge']]],
  ['hilera_41',['hilera',['../class_ubicacion.html#abf00d08075e75ac833de7357ebc6f521',1,'Ubicacion::hilera()'],['../_area___emmagatzematge_8cc.html#a04c9db241ada6360c11efa1ad51b589e',1,'Hilera():&#160;Area_Emmagatzematge.cc']]],
  ['hileras_42',['hileras',['../class_area___emmagatzematge.html#adf61396bfa7dffb2e75f61ae64e253ce',1,'Area_Emmagatzematge']]],
  ['hueco_43',['Hueco',['../class_hueco.html',1,'Hueco'],['../class_hueco.html#a149accc4b66d81fd9df72d5f02be4c2e',1,'Hueco::Hueco()'],['../class_hueco.html#a1c58ddef61cdbba02ea739b5520878d1',1,'Hueco::Hueco(const Ubicacion &amp;U, int l)'],['../class_hueco.html#aedab4c238cb6d1f07f406776b925c58d',1,'Hueco::Hueco(const Hueco &amp;H)']]],
  ['hueco_2ehh_44',['Hueco.hh',['../_hueco_8hh.html',1,'']]]
];
