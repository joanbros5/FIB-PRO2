var searchData=
[
  ['inserta_45',['inserta',['../class_area___emmagatzematge.html#a24f852e24ec94318da86114e1592fd32',1,'Area_Emmagatzematge']]],
  ['insertahueco_46',['InsertaHueco',['../class_area___emmagatzematge.html#a9e2110b95910059907a128dc23353e59',1,'Area_Emmagatzematge']]]
];
