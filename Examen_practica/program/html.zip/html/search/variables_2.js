var searchData=
[
  ['espera_194',['espera',['../class_area___emmagatzematge.html#a5217ae003cd81f4808c91447159fa46f',1,'Area_Emmagatzematge::espera()'],['../class_espera.html#a630e1a154bc8177f0825fbf2a8f2644d',1,'Espera::espera()']]]
];
