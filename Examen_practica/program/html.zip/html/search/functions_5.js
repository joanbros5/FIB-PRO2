var searchData=
[
  ['hilera_147',['hilera',['../class_ubicacion.html#abf00d08075e75ac833de7357ebc6f521',1,'Ubicacion']]],
  ['hileras_148',['hileras',['../class_area___emmagatzematge.html#adf61396bfa7dffb2e75f61ae64e253ce',1,'Area_Emmagatzematge']]],
  ['hueco_149',['Hueco',['../class_hueco.html#a149accc4b66d81fd9df72d5f02be4c2e',1,'Hueco::Hueco()'],['../class_hueco.html#a1c58ddef61cdbba02ea739b5520878d1',1,'Hueco::Hueco(const Ubicacion &amp;U, int l)'],['../class_hueco.html#aedab4c238cb6d1f07f406776b925c58d',1,'Hueco::Hueco(const Hueco &amp;H)']]]
];
