var searchData=
[
  ['area_5femmagatzematge_98',['Area_Emmagatzematge',['../class_area___emmagatzematge.html',1,'']]]
];
