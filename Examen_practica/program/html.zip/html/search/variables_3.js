var searchData=
[
  ['h_195',['H',['../class_area___emmagatzematge.html#a0dcff0ca0060b1bcb6fcd7423e8c4b72',1,'Area_Emmagatzematge']]]
];
